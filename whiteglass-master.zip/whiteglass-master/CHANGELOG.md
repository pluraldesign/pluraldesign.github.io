# ChangeLog

## 1.3.0 (2017-02-20)

- Fix typos of the theme description
- Add powered-by links to the footer

## 1.2.1 (2017-01-23)

- Make theme can be overridden (#2)

## 1.2.0 (2017-01-16)

- Use excerpt for meta tags (#1)

## 1.1.0 (2017-01-07)

- Make feed path configurable
- Empty `head_custom.html` to prevent adding comments

## 1.0.1 (2017-01-07)

- Fix RSS feed URL
- Bump jekyll-sitemap to 1.0

## 1.0.0 (2017-01-06)

- Initial release
